# TrailLabeler for PixInsight

A PixInsight script for checking the results of SatelliteTrailRemover frame by frame and recording what you see:
which trails were removed correctly, which removals were not trails, which trails are still visible, and which
were missed. The verdicts go into a JSON file that can be used to measure and improve the trail detection.

Version 1.1 · Author: Erellaz · License: MIT

Not yet run inside PixInsight. It was tested in Node.js against mocks of the PixInsight classes on 212 real
frames (see [Testing](#testing)).

## Installation

1. Copy `TrailLabeler.js` into the folder that holds `SatelliteTrailRemover.js`.
2. In PixInsight: **Script › Feature Scripts…**, click **Add**, select that folder, then **Done**.
3. Run it from **Script › BlackRig › TrailLabeler**.

## What it works on

The output folder of a WBPP run cleaned by SatelliteTrailRemover: the folder that holds `registered/` and
`detrailed/`. Either the WBPP step or the standalone script's WBPP mode produces it. The script reads, per group:

- the registered frames, `registered/<group>/*.xisf`;
- the cleaned copies, `detrailed/<group>/*.xisf` (only frames with a trail have one);
- the reference stack, `detrailed/<group>/STR_reference.xisf` (or `master/masterLight_<group>.xisf`), for the
  residual view;
- the report, `detrailed/<group>/SatelliteTrailRemover_report.csv`, for the script's detections.

It never modifies any of these files. It writes only `trail_labels.json` in the folder you open. The last
folder is reopened at the next start.

## Modes

- **Review cleaned frames:** every frame the script cleaned, with the registered frame on the left and the
  cleaned frame on the right. Verdicts: **Correct** (C), **False positive** (F), **Incomplete removal** (I),
  **Missed trail** (M), **Unsure** (U).
- **Hunt all frames:** every registered frame in one panel, showing the final frame (the cleaned copy if there is
  one, the registered frame otherwise), to find trails the script missed. Verdicts: **No trail** (C), **Missed
  trail** (M), **Incomplete removal** (I), **Unsure** (U).

**Correct** and **No trail** move to the next frame when *Advance after Correct / No trail* is ticked. A verdict
that contradicts another (for example Correct after Incomplete removal) asks before removing it.

## Drawing trails

Press **False positive**, **Incomplete removal** or **Missed trail** (or F / I / M), then click both ends of each
trail; draw as many as needed. While drawing, a dashed line follows the mouse from the first end. **Esc** stops
drawing; **Backspace** removes the last trail (or the first end, if only one is set). For a false positive, draw
along the feature the script removed by mistake.

## Views

| Key | View | What it shows |
|---|---|---|
| 1 | Image | The linear frames with an automatic stretch, the same on both panels. Contrast 1–10. |
| 2 | Residual | Frame minus the reference stack matched to it, in noise units. Faint trails stand out. |
| 3 | Removed | Right panel: registered minus cleaned, i.e. what the script subtracted (Review mode only). |

- **Zoom:** mouse wheel, or + and −. **0** or Home shows the whole frame.
- **Pan:** drag with the mouse.
- **Resolution:** zoomed out, the panels show 4×4-binned means (lower noise, faint trails show better). From 1:1
  upwards they show full-resolution pixels.
- **Script detections (D):** the script's lines (dashed lines on each side, with their score z) and blobs
  (dotted circles). *gap* keeps the dashed lines at least that many screen pixels from the trail, so the trail
  itself stays visible; *centre line* also draws the line's centre.
- **Navigation:** Next / Prev (→ / ←, N / P, Page Down / Page Up), and *Next unlabeled*.

The status line shows the drawing state, how many frames of the list are labelled, the zoom, the noise per pixel
and per bin, and the mouse position in full-resolution pixels.

## The labels file

`<folder>/trail_labels.json` is saved after every change. Its `conventions` entry explains every field. Per frame
(key `<group folder>/<file name>`), it holds the script's action and detections and, for each mode, the
verdicts (`flags`), the drawn trails (`trails`: kind and both ends, in full-resolution pixels of the registered
frame, origin at the top-left pixel), the note, the time and the labeller version.

The file is plain ASCII (characters such as the degree sign in file names are written as `\u` escapes). It has the
same format as the files of the Python TrailLabeler 1.0, so both tools can work on the same folder.

## Memory and speed

Each frame is read in full: the registered frame and, in Review mode, its cleaned copy, plus the group's reference
stack (kept while you stay in the group). That is about 1.2 GB for 100-megapixel monochrome frames. Moving to
another frame takes a few seconds (reading plus the statistics of the residual view). The Python tool loaded the
next frame in the background; this version does not.

## Testing

A Node.js test (not part of this package) ran the script against mocks of the PixInsight classes, with real
11664×8750 frames from a WBPP run cleaned by SatelliteTrailRemover 3.0 (212 frames, 47 cleaned):

- the folder scan gives the same frames, groups, indices, report columns and references as the Python tool;
- the frame statistics used for display (gain against the reference, noise per pixel and per bin, stretch)
  agree with the Python tool to within 0.4 %;
- every view renders at the zoomed-out and full-resolution levels;
- drag, wheel zoom, keys, drawing a trail with two clicks, verdict conflicts (with confirmation), automatic
  advance, notes and Hunt mode behave as described;
- opening a folder and moving between frames does not rewrite the labels file, and labels written by this script
  are read correctly by the Python tool.

It does not exercise PixInsight's own drawing, file reading or dialog layout.

## Version history

| Version | Changes |
|---|---|
| 1.1 | PixInsight version of the Python TrailLabeler 1.0, same labels file. Fixed: opening a folder could overwrite the label of the first frame of the list with an empty one (also fixed in the Python tool, 1.0.1). |
| 1.0 | Python tool (Tk), Review and Hunt modes. |

## License

MIT. See `LICENSE.txt`.
